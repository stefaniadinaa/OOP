public class ResumeIncompleteException extends Exception {
    public ResumeIncompleteException(String message) {
        super(message);
    }
}
