public class Constraint {
    // limita inferioara impusa
    public int lowerLimit;
    // limita superioara impusa
    public int upperLimit;
}
